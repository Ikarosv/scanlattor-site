declare namespace findAll {
  interface props {
    page?: number;
    search?: string;
  }
}
