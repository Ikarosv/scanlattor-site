module.exports = require('./dist/index.js');
